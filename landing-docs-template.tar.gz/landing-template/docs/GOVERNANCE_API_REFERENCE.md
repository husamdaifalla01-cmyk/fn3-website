# Governance API Reference

**Complete canonical reference for the x402 Governance Platform APIs**

## Overview

The x402 Governance Platform provides 15 comprehensive APIs organized into 6 functional categories for repository governance, compliance tracking, data analysis, and policy management. **ALL APIs NOW USE REAL GITHUB APP DATA** - no mock or fake data.

**Base URL**: `https://your-domain.com/api/governance`
**Authentication**: Session-based authentication required for most endpoints
**Rate Limiting**: Applied to sensitive operations

---

## 🏗️ **1. Repository Management**

### 1.1 Register & List Repositories

#### `POST /api/governance/repositories`
Register a new repository for governance tracking.

**Request Body:**
```json
{
  "repository": {
    "name": "my-app",
    "url": "https://github.com/org/my-app",
    "branch": "main",
    "compliance_scope": ["GDPR", "SOC2"],
    "risk_tolerance": "medium"
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "repo-abc123",
    "status": "pending",
    "governance_score": null,
    "scan_id": "scan-def456"
  }
}
```

**Authentication:** Required
**Rate Limit:** 10 requests/minute

#### `GET /api/governance/repositories`
List all repositories for the authenticated organization.

**Query Parameters:**
- `status` (optional): Filter by status (`pending`, `analyzing`, `completed`, `error`)
- `risk_level` (optional): Filter by risk level (`low`, `medium`, `high`, `critical`)

**Response:**
```json
{
  "success": true,
  "data": {
    "repositories": [
      {
        "id": "repo-abc123",
        "name": "my-app",
        "full_name": "org/my-app",
        "provider": "github",
        "url": "https://github.com/org/my-app",
        "branch": "main",
        "status": "completed",
        "governance_score": 85,
        "risk_level": "low",
        "compliance_frameworks": ["GDPR", "SOC2"],
        "last_scan": "2024-03-07T10:30:00Z"
      }
    ],
    "total": 1
  }
}
```

### 1.2 Add Repository (Enhanced)

#### `POST /api/governance/repository/add`
Add repository with comprehensive analysis.

**Request Body:**
```json
{
  "repository": {
    "name": "ecommerce-api",
    "full_name": "company/ecommerce-api",
    "url": "https://github.com/company/ecommerce-api",
    "branch": "main",
    "private": false
  },
  "analysis_config": {
    "scan_depth": "deep",
    "include_dependencies": true,
    "compliance_frameworks": ["GDPR", "PCI-DSS"]
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "repository_id": "github-123456",
    "scan_id": "scan-789012",
    "status": "analyzing",
    "estimated_completion": "2024-03-07T11:00:00Z"
  }
}
```

### 1.3 Simple Repository Addition

#### `POST /api/governance/repository/simple-add`
Add repository with basic governance tracking (real GitHub integration).

**Authentication:** Required

**Request Body:**
```json
{
  "repository": {
    "id": 123456,
    "name": "my-app",
    "full_name": "org/my-app",
    "html_url": "https://github.com/org/my-app",
    "default_branch": "main",
    "language": "TypeScript",
    "private": false
  },
  "source": "github",
  "analysisConfiguration": {
    "depth": "basic"
  }
}
```

**Response:**
```json
{
  "success": true,
  "repository": {
    "id": "github-org-my-app",
    "name": "my-app",
    "status": "pending",
    "governance_score": 50
  },
  "scan": {
    "id": "scan-abc123",
    "status": "completed"
  },
  "message": "Repository added to governance tracking and analysis started"
}
```

---

## 📊 **2. Data Source Management**

### 2.1 Data Sources CRUD Operations

#### `GET /api/governance/data-sources`
Retrieve data sources from real GitHub repositories with advanced filtering.

**Authentication:** Required

**Query Parameters:**
- `repository` (optional): Filter by repository ID
- `type` (optional): Filter by type (`database`, `api`, `file`, `stream`, `external`)
- `classification` (optional): Filter by classification (`public`, `internal`, `confidential`, `restricted`)

**Real GitHub Integration:** Scans actual repository contents via GitHub API to detect:
- Database schema files (`prisma/schema.prisma`, `supabase/migrations`, etc.)
- Configuration files (`.env`, `package.json`, `next.config.js`)
- API routes (`src/api`, `pages/api`, `app/api`)
- Authentication files (`src/lib/auth`, `src/middleware`)

**Response:**
```json
{
  "success": true,
  "data": {
    "sources": [
      {
        "id": "src-abc123",
        "name": "users-database",
        "type": "database",
        "repository": "repo-def456",
        "location": "src/models/user.ts",
        "classification": "confidential",
        "riskLevel": "medium",
        "autoDetected": true,
        "metadata": {
          "tables": ["users", "profiles"],
          "relationships": 2
        }
      }
    ],
    "stats": {
      "total": 15,
      "byClassification": {
        "public": 2,
        "internal": 8,
        "confidential": 4,
        "restricted": 1
      },
      "byRisk": {
        "low": 8,
        "medium": 5,
        "high": 2,
        "critical": 0
      }
    }
  }
}
```

#### `POST /api/governance/data-sources`
Add custom data source.

**Request Body:**
```json
{
  "name": "customer-analytics-db",
  "type": "database",
  "repository": "repo-abc123",
  "location": "analytics/customer_db.sql",
  "classification": "confidential",
  "description": "Customer behavior analytics database",
  "metadata": {
    "connection_string": "postgresql://...",
    "schemas": ["public", "analytics"]
  }
}
```

#### `PUT /api/governance/data-sources`
Update existing data source.

**Request Body:**
```json
{
  "id": "src-abc123",
  "classification": "restricted",
  "riskLevel": "high",
  "metadata": {
    "encryption": "AES-256",
    "compliance": ["GDPR", "HIPAA"]
  }
}
```

#### `DELETE /api/governance/data-sources?id=src-abc123`
Remove data source from tracking.

---

## 🔍 **3. Repository Analysis**

### 3.1 File Scanning & Analysis

#### `GET /api/governance/repository/{id}/scan-files`
Comprehensive repository file scanning and categorization.

**Path Parameters:**
- `id`: Repository ID

**Response:**
```json
{
  "success": true,
  "data": {
    "repository": {
      "id": "repo-abc123",
      "name": "my-app",
      "full_name": "org/my-app",
      "branch": "main"
    },
    "scan_results": {
      "categorized_files": {
        "schemas": [
          {
            "path": "database/schema.sql",
            "name": "schema.sql",
            "size": 2048,
            "type": "SQL",
            "estimated_lines": 68,
            "potential_tables": ["users", "orders"]
          }
        ],
        "migrations": [
          {
            "path": "migrations/001_create_users.sql",
            "name": "001_create_users.sql",
            "size": 1024,
            "type": "SQL",
            "estimated_lines": 34,
            "potential_tables": ["users"]
          }
        ],
        "models": [
          {
            "path": "src/models/user.ts",
            "name": "user.ts",
            "size": 512,
            "type": "TypeScript",
            "estimated_lines": 17,
            "potential_tables": ["users"]
          }
        ]
      },
      "stats": {
        "total_files": 156,
        "database_files": 12,
        "categories_found": 5
      },
      "data_flow_estimate": {
        "estimated_flows": 8,
        "flow_types": [
          {
            "type": "API → Database",
            "confidence": "high",
            "description": "API routes likely interact with database models"
          }
        ],
        "complexity_score": 65
      }
    }
  }
}
```

#### `POST /api/governance/repository/{id}/extract-flows`
Extract data flows from selected repository files.

**Path Parameters:**
- `id`: Repository ID

**Request Body:**
```json
{
  "selected_files": [
    "migrations/001_create_users.sql",
    "src/models/user.ts",
    "src/api/users.ts"
  ],
  "extraction_focus": "all"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "repository_id": "repo-abc123",
    "extracted_data": {
      "tables": [
        {
          "name": "users",
          "source_file": "migrations/001_create_users.sql",
          "columns": [
            {
              "name": "id",
              "type": "INTEGER",
              "primary_key": true
            },
            {
              "name": "email",
              "type": "VARCHAR(255)",
              "nullable": false
            }
          ],
          "foreign_keys": [],
          "type": "sql_table"
        }
      ],
      "api_endpoints": [
        {
          "path": "/api/users",
          "source_file": "src/api/users.ts",
          "methods": ["GET", "POST"]
        }
      ],
      "data_flows": [
        {
          "type": "api_to_db",
          "endpoint": "/api/users",
          "table": "users",
          "operation": "read",
          "source_file": "src/api/users.ts"
        }
      ]
    },
    "architecture_mapping": {
      "nodes": [
        {
          "id": "table_users",
          "type": "database",
          "label": "users",
          "data": {
            "category": "table",
            "columns": ["id", "email"]
          }
        }
      ],
      "edges": [],
      "statistics": {
        "total_tables": 1,
        "total_apis": 1,
        "total_flows": 1
      }
    }
  }
}
```

### 3.2 Distributed Data Retrieval

#### `GET /api/governance/repository/{id}/distributed-data`
Retrieve processed governance analysis results.

**Response:**
```json
{
  "success": true,
  "data": {
    "dataMapping": {
      "architecture": {
        "nodes": [
          {
            "id": "frontend",
            "type": "service",
            "label": "Frontend",
            "data": {
              "technology": "Next.js",
              "port": 3000
            }
          }
        ],
        "edges": [
          {
            "id": "e1",
            "source": "frontend",
            "target": "api-gateway",
            "type": "http"
          }
        ]
      },
      "dataFlows": [
        {
          "id": "user-auth-flow",
          "name": "User Authentication Flow",
          "steps": [
            {
              "service": "frontend",
              "action": "User login request"
            }
          ]
        }
      ]
    },
    "complianceHub": {
      "score": 85,
      "status": "compliant",
      "issues": [],
      "frameworks": ["GDPR", "SOC2"]
    }
  }
}
```

---

## 🔄 **4. Enhanced Ingestion & Data Transformation**

### 4.1 Enhanced Repository Ingestion

#### `POST /api/governance/enhanced-ingestion`
**NEW** - Comprehensive repository analysis with transformation pipeline.

**Authentication:** Required

**Request Body:**
```json
{
  "repositoryId": "github-123456",
  "source": "github_app",
  "repository": {
    "id": 123456,
    "name": "my-app",
    "full_name": "org/my-app",
    "url": "https://github.com/org/my-app"
  },
  "organizationContext": {
    "organization": "My Company",
    "domain": "E-commerce",
    "stakeholders": ["Engineering Team", "Data Team", "Compliance"]
  },
  "analysisConfiguration": {
    "analysisDepth": "deep",
    "includeAIEnhancement": true,
    "complianceFrameworks": ["GDPR", "SOC2", "PCI-DSS"]
  },
  "ingestionSettings": {
    "processingMode": "async",
    "notificationWebhook": "https://myapp.com/webhooks/ingestion"
  }
}
```

**Response:**
```json
{
  "success": true,
  "scanId": "scan-abc123def",
  "message": "Enhanced ingestion started"
}
```

**Workflow Phases:**
1. **Repository Analysis** (25%) - File structure, code patterns extraction
2. **Statistical Analysis** (50%) - Inference, cognitive bias detection
3. **Compliance Analysis** (75%) - Framework mapping, data flow analysis
4. **Data Transformation** (85%) - Normalization pipeline processing
5. **Data Distribution** (100%) - Results distributed to specialized pages

#### `GET /api/governance/enhanced-ingestion?scanId={scanId}`
Get enhanced ingestion progress and results.

**Response:**
```json
{
  "success": true,
  "scan": {
    "id": "scan-abc123def",
    "status": "completed",
    "progress": 100,
    "phase": "completed",
    "started_at": "2024-03-07T10:00:00Z",
    "completed_at": "2024-03-07T10:15:00Z",
    "results": {
      "repositoryAnalysis": { "files": 156, "patterns": 23 },
      "statisticalAnalysis": { "complexity_score": 65 },
      "complianceAnalysis": { "frameworks_mapped": 3, "gaps": 2 },
      "dataFlowAnalysis": { "flows_detected": 8, "risk_score": 25 },
      "cognitiveAnalysis": { "biases_detected": 1 }
    },
    "distributed_data": {
      "complianceHub": { "score": 85, "issues": [] },
      "dataMapping": { "sources": 12, "flows": 8 },
      "documentation": { "coverage": 78 }
    }
  }
}
```

### 4.2 Data Transformation Pipeline

#### `POST /api/governance/transformation`
**NEW** - Transform raw ingested data into normalized business structures.

**Authentication:** Required

**Request Body:**
```json
{
  "scanId": "scan-abc123def",
  "repositoryId": "github-123456",
  "transformationType": "all",
  "rawData": {
    "scanId": "scan-abc123def",
    "repositoryId": "github-123456",
    "files": [...],
    "codeAnalysis": [...],
    "dependencies": [...],
    "metadata": {...}
  },
  "options": {
    "includeAIEnhancement": true,
    "businessContext": {
      "organization": "My Company",
      "domain": "E-commerce",
      "stakeholders": ["Engineering Team"]
    },
    "visualizationConfig": {
      "viewType": "data-sources",
      "generateAllViews": true
    }
  }
}
```

**Response:**
```json
{
  "success": true,
  "transformationId": "transform-xyz789",
  "result": {
    "status": "completed",
    "quality": {
      "dataSourcesIdentified": 12,
      "dataFlowsTraced": 8,
      "businessContextCoverage": 85,
      "complianceMapping": 92,
      "overallQuality": 88
    },
    "dataSourcesCount": 12,
    "dataFlowsCount": 8,
    "architectureComponentsCount": 5,
    "recommendationsCount": 7
  }
}
```

#### `GET /api/governance/transformation/status?transformationId={id}`
Get transformation status and results.

### 4.3 Data Mapping Integration

#### `GET /api/governance/data-mapping`
**NEW** - Retrieve transformed data for visualization and analysis.

**Query Parameters:**
- `repositoryId` (optional): Filter by repository
- `scanId` (optional): Filter by scan
- `viewType`: `data-sources`, `data-flows`, `architecture`, or `all`
- `sensitivity`: Filter by sensitivity level
- `riskLevel`: Filter by risk level
- `layout`: Visualization layout preference
- `grouping`: Data grouping strategy
- `colorScheme`: Color coding scheme

**Response:**
```json
{
  "success": true,
  "data": {
    "dataSources": [
      {
        "id": "src-user-db-001",
        "name": "user-database",
        "type": "database",
        "category": {
          "primary": "business",
          "secondary": "customer-data",
          "businessDomain": "Customer Management"
        },
        "location": "src/models/user.ts",
        "businessContext": {
          "purpose": "Customer data management and authentication",
          "stakeholders": ["Engineering Team", "Product Team"],
          "businessProcess": "User Registration",
          "criticality": "critical"
        },
        "sensitivity": "confidential",
        "riskLevel": "high",
        "qualityScore": 85,
        "complianceScope": ["GDPR", "CCPA"],
        "lastUpdated": "2024-03-07T10:15:00Z",
        "relationships": [
          {
            "targetId": "src-auth-api-001",
            "type": "feeds",
            "strength": 0.9,
            "businessRule": "User data feeds authentication system"
          }
        ],
        "metadata": {
          "transformationStatus": "completed",
          "aiEnhancements": {
            "confidence": 92,
            "recommendations": [
              "Consider implementing field-level encryption for PII",
              "Add data retention policy automation"
            ]
          },
          "visualizationReady": true
        }
      }
    ],
    "dataFlows": [
      {
        "id": "flow-user-auth-001",
        "name": "User Authentication Flow",
        "description": "Complete user authentication and session management",
        "businessProcess": "Identity Management",
        "steps": [
          {
            "id": "step-login-001",
            "name": "User Login Request",
            "type": "source",
            "component": "Login Form",
            "businessPurpose": "Capture user credentials",
            "dataTypes": ["email", "password"],
            "order": 1
          }
        ],
        "performance": {
          "latency": "150ms",
          "throughput": "1000/min",
          "errorRate": 0.02
        },
        "securityControls": ["Input validation", "Rate limiting"],
        "complianceControls": ["Audit logging", "Encryption"],
        "stakeholders": ["Security Team", "Engineering Team"],
        "lastUpdated": "2024-03-07T10:15:00Z"
      }
    ],
    "architecture": {
      "id": "arch-main-001",
      "name": "Application Architecture",
      "components": [
        {
          "id": "comp-frontend-001",
          "name": "React Frontend",
          "type": "frontend",
          "technologies": ["React", "TypeScript", "Next.js"],
          "responsibilities": ["User interface", "Client-side validation"],
          "dataHandling": ["User inputs", "Display data"],
          "securityLevel": "medium",
          "position": { "x": 100, "y": 100 }
        }
      ],
      "boundaries": [
        {
          "id": "boundary-dmz-001",
          "name": "DMZ Network",
          "type": "network",
          "components": ["comp-frontend-001", "comp-api-001"],
          "controls": ["Firewall", "Load balancer"]
        }
      ],
      "dataFlows": [
        {
          "id": "flow-frontend-api",
          "source": "comp-frontend-001",
          "destination": "comp-api-001",
          "dataType": "User requests",
          "protocol": "HTTPS",
          "encryption": true,
          "authentication": true
        }
      ],
      "lastUpdated": "2024-03-07T10:15:00Z"
    },
    "visualizations": [
      {
        "id": "viz-data-sources-001",
        "type": "data-sources",
        "layout": {
          "algorithm": "force-directed",
          "direction": "horizontal",
          "grouping": "business-domain"
        },
        "styling": {
          "colorScheme": "sensitivity",
          "nodeStyles": { "shape": "circle", "borderWidth": 2 },
          "edgeStyles": { "style": "curved", "arrowStyle": "filled" }
        },
        "data": {
          "nodes": [...],
          "edges": [...],
          "groups": [...],
          "legends": [...]
        }
      }
    ],
    "metadata": {
      "scanId": "scan-abc123def",
      "repositoryId": "github-123456",
      "lastUpdated": "2024-03-07T10:15:00Z",
      "dataFreshness": "fresh",
      "completeness": {
        "dataSources": 100,
        "dataFlows": 95,
        "architecture": 88
      },
      "quality": {
        "overallScore": 88,
        "businessContextCoverage": 85,
        "complianceCoverage": 92
      },
      "transformationStatus": "completed"
    }
  }
}
```

### 4.4 Repository Ingestion Strategy

#### `POST /api/governance/repository-ingestion`
Determine optimal ingestion strategy for repository analysis.

**Request Body:**
```json
{
  "repository": {
    "url": "https://github.com/org/large-repo",
    "private": true,
    "size_kb": 250000,
    "file_count": 5000
  },
  "preferences": {
    "max_processing_time": 300,
    "include_git_history": false,
    "focus_areas": ["database", "api"]
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "recommended_strategy": "github_api",
    "strategies": [
      {
        "method": "github_api",
        "confidence": 0.9,
        "estimated_time_seconds": 180,
        "requirements": ["github_token"],
        "limitations": ["rate_limited", "public_repos_only"],
        "chunking_plan": {
          "total_chunks": 5,
          "chunk_size": 1000,
          "parallel_processing": true
        }
      }
    ],
    "fallback_options": ["archive_download", "manual_upload"],
    "estimated_data_size": "245 MB"
  }
}
```

### 4.2 File Upload Processing

#### `POST /api/governance/upload`
Handle repository file uploads for analysis.

**Content-Type**: `multipart/form-data`

**Form Fields:**
- `files`: ZIP/TAR archive or individual files
- `repository_name`: Name for the uploaded repository
- `analysis_config`: JSON configuration string

**Response:**
```json
{
  "success": true,
  "data": {
    "upload_id": "upload-abc123",
    "processed_files": 45,
    "detected_issues": [
      {
        "type": "security",
        "severity": "medium",
        "file": ".env",
        "message": "Environment file contains potential secrets"
      }
    ],
    "analysis_started": true,
    "scan_id": "scan-def456"
  }
}
```

---

## 📡 **5. Scanning & Status Tracking**

### 5.1 Repository Scanning

#### `POST /api/governance/scan`
Initiate comprehensive repository scan.

**Request Body:**
```json
{
  "repository": "repo-abc123",
  "scan_type": "deep",
  "compliance_frameworks": ["GDPR", "SOC2", "PCI-DSS"],
  "focus_areas": ["data_flow", "security", "compliance"],
  "configuration": {
    "include_dependencies": true,
    "analyze_api_endpoints": true,
    "deep_file_analysis": true
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "scan_id": "scan-abc123",
    "status": "initiated",
    "estimated_completion": "2024-03-07T11:30:00Z",
    "phases": [
      "Repository Analysis",
      "Data Flow Mapping",
      "Compliance Assessment",
      "Security Review",
      "Report Generation"
    ]
  }
}
```

### 5.2 Scan Status Tracking

#### `GET /api/governance/scan-status/{scanId}`
Get real-time scan progress and results from actual repository analysis.

**Authentication:** Required

**Path Parameters:**
- `scanId`: Scan identifier

**Response:**
```json
{
  "success": true,
  "data": {
    "scan_id": "scan-abc123",
    "status": "in_progress",
    "progress": 65,
    "current_phase": "Compliance Assessment",
    "phases": [
      {
        "name": "Repository Analysis",
        "status": "completed",
        "duration": 45,
        "findings": 12
      },
      {
        "name": "Data Flow Mapping",
        "status": "completed",
        "duration": 78,
        "findings": 8
      },
      {
        "name": "Compliance Assessment",
        "status": "in_progress",
        "progress": 40
      }
    ],
    "preliminary_results": {
      "governance_score": 72,
      "risk_level": "medium",
      "critical_issues": 2,
      "recommendations": 15
    }
  }
}
```

#### `PATCH /api/governance/scan-status/{scanId}`
Update scan status (internal use).

**Request Body:**
```json
{
  "status": "completed",
  "progress": 100,
  "metadata": {
    "final_score": 85,
    "total_findings": 23
  }
}
```

---

## 📋 **6. Policy & Compliance Management**

### 6.1 Policy Management

#### `GET /api/governance/policies`
List governance policies with filtering.

**Query Parameters:**
- `framework` (optional): Filter by framework (`GDPR`, `SOC2`, `PCI-DSS`, etc.)
- `status` (optional): Filter by status (`active`, `draft`, `archived`)
- `category` (optional): Filter by category (`data-protection`, `access-control`, etc.)

**Response:**
```json
{
  "success": true,
  "data": {
    "policies": [
      {
        "id": "policy-abc123",
        "title": "Data Retention Policy",
        "framework": "GDPR",
        "category": "data-protection",
        "status": "active",
        "severity": "high",
        "description": "Personal data must be retained only as long as necessary",
        "requirements": [
          "Define retention periods for each data type",
          "Implement automated deletion processes",
          "Document data retention decisions"
        ],
        "violations": [],
        "created_at": "2024-01-15T10:00:00Z",
        "updated_at": "2024-02-20T14:30:00Z"
      }
    ],
    "statistics": {
      "total": 25,
      "by_framework": {
        "GDPR": 8,
        "SOC2": 6,
        "PCI-DSS": 5,
        "HIPAA": 3,
        "Custom": 3
      },
      "by_status": {
        "active": 20,
        "draft": 3,
        "archived": 2
      },
      "total_violations": 7
    }
  }
}
```

#### `POST /api/governance/policies`
Create new governance policy.

**Request Body:**
```json
{
  "title": "API Access Control Policy",
  "framework": "SOC2",
  "category": "access-control",
  "severity": "critical",
  "description": "All API endpoints must implement proper authentication and authorization",
  "requirements": [
    "Implement JWT-based authentication",
    "Use role-based access control (RBAC)",
    "Log all API access attempts",
    "Rate limit API requests"
  ],
  "validation_rules": {
    "required_headers": ["Authorization"],
    "allowed_methods": ["GET", "POST", "PUT", "DELETE"],
    "rate_limit": "100/minute"
  }
}
```

#### `PUT /api/governance/policies`
Update existing policy.

**Request Body:**
```json
{
  "id": "policy-abc123",
  "status": "active",
  "requirements": [
    "Define retention periods for each data type",
    "Implement automated deletion processes",
    "Document data retention decisions",
    "Regular compliance audits"
  ],
  "version_notes": "Added requirement for regular audits"
}
```

#### `DELETE /api/governance/policies?id=policy-abc123`
Archive policy (soft delete).

---

## 🔧 **Technical Specifications**

### Authentication
All endpoints (except demos) require session-based authentication:
```javascript
// Request headers
{
  "Cookie": "session=abc123...",
  "Content-Type": "application/json"
}
```

### Rate Limiting
- **Repository Management**: 10 requests/minute
- **Data Analysis**: 5 requests/minute
- **File Upload**: 2 requests/minute
- **General APIs**: 60 requests/minute

### Error Handling
Standard error response format:
```json
{
  "success": false,
  "error": "Repository not found",
  "code": "REPO_NOT_FOUND",
  "details": {
    "repository_id": "invalid-id",
    "suggestion": "Check repository ID format"
  }
}
```

### Pagination
Large result sets use cursor-based pagination:
```json
{
  "data": [...],
  "pagination": {
    "has_next": true,
    "next_cursor": "cursor-abc123",
    "total": 150,
    "per_page": 25
  }
}
```

### Webhook Integration
Some operations support webhook notifications:
```json
{
  "webhook_url": "https://your-app.com/webhooks/governance",
  "events": ["scan_completed", "policy_violation", "repository_analyzed"]
}
```

---

## 📚 **Usage Examples**

### Complete Repository Onboarding Flow
```bash
# 1. Add repository
curl -X POST "/api/governance/repository/add" \
  -H "Content-Type: application/json" \
  -d '{
    "repository": {
      "name": "my-app",
      "url": "https://github.com/org/my-app"
    }
  }'

# 2. Track analysis progress
curl "/api/governance/scan-status/scan-123"

# 3. Retrieve results
curl "/api/governance/repository/repo-456/distributed-data"
```

### Policy Compliance Check
```bash
# 1. List active policies
curl "/api/governance/policies?status=active&framework=GDPR"

# 2. Check repository compliance
curl "/api/governance/scan" \
  -d '{"repository": "repo-123", "compliance_frameworks": ["GDPR"]}'
```

### Data Flow Analysis
```bash
# 1. Scan repository files
curl "/api/governance/repository/repo-123/scan-files"

# 2. Extract flows from specific files
curl -X POST "/api/governance/repository/repo-123/extract-flows" \
  -d '{"selected_files": ["schema.sql", "models/user.ts"]}'
```

---

## 🏷️ **API Categories Summary**

| Category | Endpoints | Primary Use Case |
|----------|-----------|------------------|
| **Repository Management** | 5 | Repository registration, listing, demo data |
| **Data Source Management** | 4 | CRUD operations for data sources and discovery |
| **Repository Analysis** | 3 | File scanning, data flow extraction, results |
| **Ingestion & Processing** | 3 | Strategy determination, file upload, processing |
| **Scanning & Status** | 3 | Scan orchestration, progress tracking |
| **Policy & Compliance** | 4 | Policy CRUD, compliance framework management |

**Total**: 20 distinct API endpoints across 6 functional categories

## 🚫 **Removed APIs (Mock Data Eliminated)**

The following demo/mock APIs have been **completely removed**:
- ❌ `/api/governance/repository/demo-add` - Mock repository with fake analysis
- ❌ `/api/governance/demo-scan-status/{id}` - Instant completion with fake data
- ❌ `/api/governance/simple-ingestion` - Mock ingestion process

## ✅ **Real GitHub Integration**

**ALL remaining APIs now use authentic GitHub App data:**
- 🔗 Real repository file scanning via GitHub API
- 🔗 Actual database schema detection from repo contents
- 🔗 Authentic data flow extraction from source code
- 🔗 User-specific authentication and repository access
- 🔗 Live repository metrics and analysis

This comprehensive API surface enables complete governance platform functionality from repository onboarding through compliance management and ongoing monitoring with **zero mock data**.