# Portfolio Management Impact Map

## Canonical Definition
User portfolio tracking system for AI vendor relationships, spend analysis, risk assessment, and optimization recommendations. Enables users to track their AI vendor usage, analyze costs, monitor risk exposure, and receive strategic guidance based on ADES (AI Dependency Exposure Score) methodology.

## Business Criticality
- **Revenue Impact:** HIGH - primary paid feature driving subscription revenue
- **User Impact:** All paid tier users managing AI vendor portfolios
- **Development Frequency:** 3-4 changes/month (new features, analysis improvements)

## Implementation Locations

### Database Layer
- **Tables**: `portfolios`, `user_vendors`, `spend_analysis`, `risk_assessments` (schema.ts:250-300)
- **Portfolio Data**: User AI vendor relationships, usage patterns
- **Analytics**: Historical spend data, risk trends, optimization opportunities

### Portfolio Pages
- **Portfolio Dashboard**: `landing/app/(dashboard)/dashboard/portfolio/page.tsx`
- **Vendor Management**: Add/remove AI vendors, configure usage tracking
- **Risk Analysis**: Portfolio-wide risk assessment, concentration analysis
- **Spend Analytics**: Cost breakdown, trend analysis, optimization recommendations

### ADES Calculation
- **ADES Algorithm**: `api/src/services/ades-calculator.ts` - dependency risk scoring
- **Risk Aggregation**: Portfolio-level risk calculation from individual vendors
- **Concentration Metrics**: Vendor dependency concentration analysis

### Integration Points
- **Provider Data**: Links to AI Provider Intelligence for vendor information
- **Spend Tracking**: Integration with user billing/usage data
- **Risk Alerts**: Portfolio risk threshold alerts

### Analytics Services
- **Portfolio Analytics**: `api/src/services/portfolio-analytics.ts` - trend analysis
- **Optimization Engine**: Vendor recommendation algorithms
- **Benchmarking**: Industry comparison and best practices

### API Endpoints
- **Portfolio Data**: `api/src/routes/portfolio.ts` - portfolio management endpoints
- **Vendor Operations**: Add/edit/remove vendor relationships
- **Analytics**: Portfolio metrics, trend data, recommendations

## Dependencies (concepts this relies on)
- AI Provider Intelligence (vendor data, risk scores)
- User Authentication & Authorization (user portfolio ownership)
- Quality Scoring System (vendor quality metrics)
- AVRS Risk Scoring (individual vendor risk inputs)

## Dependents (concepts that rely on this)
- Alert & Notification System (portfolio-based alerts)
- Subscription & Billing System (portfolio features by tier)

## Change Procedure Checklist
- [ ] Update portfolio database schema if needed
- [ ] Test ADES calculation algorithm changes
- [ ] Update portfolio dashboard UI components
- [ ] Verify vendor management functionality
- [ ] Test portfolio analytics and reporting
- [ ] Update optimization recommendation logic
- [ ] Test integration with provider intelligence data
- [ ] Verify portfolio-based alert generation
- [ ] Test tier-based feature access

## Common Change Patterns
- **ADES Algorithm Updates**: Improving dependency risk calculation
- **New Analytics Features**: Additional portfolio insights, metrics
- **UI/UX Improvements**: Better portfolio visualization, user experience
- **Integration Enhancements**: Deeper vendor data integration

## Risk Assessment
- **Change Complexity:** MEDIUM-HIGH - complex analytics, multiple data sources
- **Testing Difficulty:** MEDIUM-HIGH - requires portfolio data scenarios
- **Rollback Difficulty:** MEDIUM - user portfolio data complicates rollbacks

## Owner
- **Primary:** Product Engineering Team
- **Technical:** Senior Full-Stack Engineer (analytics focus)
- **Business:** Head of Product (portfolio features)

## Feature Standards
- ADES calculation accuracy > 90% for risk prediction
- Portfolio analytics update within 24 hours of data changes
- Recommendation relevance > 80% user acceptance rate
- Real-time portfolio risk monitoring