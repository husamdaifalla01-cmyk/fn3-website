# Quality Scoring System Impact Map

## Canonical Definition
ML-based system that evaluates AI provider service reliability through multiple quality dimensions: settlement rates, pricing stability, API uptime, support responsiveness, and ecosystem health. Generates composite quality scores (0-100) used for provider rankings and risk assessments.

## Business Criticality
- **Revenue Impact:** HIGH - quality scores drive user provider selection decisions
- **User Impact:** All portfolio management and risk analysis users
- **Development Frequency:** 1-2 algorithm updates/month, weekly score refreshes

## Implementation Locations

### Scoring Algorithms
- **Quality Calculator**: `api/src/services/quality-scorer.ts` - main scoring logic
- **Settlement Analysis**: `api/src/services/settlement-analyzer.ts` - payment reliability
- **Pricing Stability**: `api/src/services/pricing-stability.ts` - cost predictability
- **API Health**: `api/src/services/api-health-monitor.ts` - uptime tracking

### Database Layer
- **Tables**: `quality_scores`, `provider_metrics`, `settlement_data` (schema.ts:400-450)
- **Historical Data**: Time-series quality metrics, trend analysis
- **Aggregations**: Daily/weekly/monthly quality rollups

### Data Sources
- **Settlement Data**: x402 payment transaction analysis
- **Pricing Data**: Historical provider pricing changes
- **API Monitoring**: Uptime/latency data from external monitors
- **User Feedback**: Support ticket analysis, user satisfaction scores

### Frontend Display
- **Provider Cards**: Quality badges, trend indicators
- **Quality Charts**: `landing/components/dashboard/quality-charts.tsx`
- **Provider Rankings**: Sorted by composite quality scores
- **Quality Filters**: Filter providers by quality thresholds

### Background Processing
- **Score Updates**: Daily quality score recalculation
- **Data Collection**: Automated metrics gathering
- **Anomaly Detection**: Quality score spike/drop alerts
- **Model Retraining**: Periodic ML model updates

### API Endpoints
- **Quality Data**: `api/src/routes/quality.ts` - quality score endpoints
- **Provider Rankings**: Quality-based provider ordering
- **Historical Trends**: Quality score evolution over time

## Dependencies (concepts this relies on)
- Settlement Analytics & Indexing (payment reliability data)
- AI Provider Intelligence (provider metadata)
- Background Job System (automated score updates)
- Database Schema & Migrations (quality tables)

## Dependents (concepts that rely on this)
- AVRS Risk Scoring (quality inputs to risk calculation)
- Portfolio Management (provider recommendations)
- AI Provider Intelligence (quality-enhanced provider data)
- Frontend State Management (quality score display)

## Change Procedure Checklist
- [ ] Update scoring algorithm in quality-scorer.ts
- [ ] Test new scoring on historical data
- [ ] Update database schema for new quality metrics
- [ ] Refresh background job configurations
- [ ] Update frontend components displaying quality scores
- [ ] Test API endpoints returning quality data
- [ ] Verify provider rankings update correctly
- [ ] Update quality-based filtering and search
- [ ] Test alert generation for quality changes

## Common Change Patterns
- **Algorithm Improvements**: Better quality prediction accuracy
- **New Quality Dimensions**: Additional scoring factors
- **Data Source Integration**: New monitoring systems, feedback channels
- **UI Enhancements**: Better quality score visualization

## Risk Assessment
- **Change Complexity:** MEDIUM-HIGH - affects provider rankings and recommendations
- **Testing Difficulty:** HIGH - requires historical data validation
- **Rollback Difficulty:** MEDIUM - score changes affect user experience

## Owner
- **Primary:** Data Science + Backend Engineering Team
- **Technical:** Senior Backend Engineer (ML focus)
- **Business:** Head of Data Science

## Quality Standards
- Scoring accuracy > 90% correlation with user satisfaction
- Score update latency < 24 hours for new data
- Historical score stability (no wild fluctuations)
- Transparent scoring methodology for user trust