# Subscription & Billing System Impact Map

## Canonical Definition
Stripe-integrated subscription management system handling user billing, tier management (free/pro/business/enterprise), usage limits enforcement, billing cycle management, and payment processing. Includes prorations, upgrades/downgrades, and billing analytics.

## Business Criticality
- **Revenue Impact:** CRITICAL - directly handles all subscription revenue
- **User Impact:** All paid users if billing system fails
- **Development Frequency:** 2-3 changes/month (tier updates, billing improvements)

## Implementation Locations

### Database Layer
- **Tables**: `subscriptions`, `invoices`, `usage_tracking`, `billing_events` (schema.ts:150-200)
- **Subscription Data**: User tiers, billing cycles, payment status
- **Usage Metrics**: Feature usage tracking, limit enforcement

### Billing Pages
- **Billing Dashboard**: `landing/app/(dashboard)/dashboard/billing/page.tsx`
- **Subscription Management**: Upgrade/downgrade, payment method updates
- **Usage Analytics**: Current usage, billing history, invoice access

### Stripe Integration
- **Stripe Service**: `api/src/services/stripe.ts` - payment processing
- **Webhook Handler**: `api/src/routes/stripe-webhooks.ts` - Stripe event processing
- **Price Management**: Stripe price/product synchronization

### Tier Enforcement
- **Tier Middleware**: `api/src/middleware/tier-enforcement.ts` - feature access control
- **Usage Limits**: API rate limiting, feature usage caps
- **Upgrade Prompts**: UI prompts for tier limitations

### Billing Logic
- **Subscription Manager**: `api/src/services/subscription-manager.ts` - subscription lifecycle
- **Proration Calculator**: Upgrade/downgrade billing calculations
- **Usage Aggregator**: Feature usage measurement and reporting

### Payment Processing
- **Payment Methods**: Credit card, ACH, wire transfer support
- **Invoice Generation**: Automated invoicing, PDF generation
- **Payment Retry**: Failed payment recovery workflows

## Dependencies (concepts this relies on)
- User Authentication & Authorization (subscription ownership)
- Database Schema & Migrations (billing tables)
- Environment & Configuration Management (Stripe keys)

## Dependents (concepts that rely on this)
- Alert & Notification System (tier-based alert features)
- Portfolio Management (tier-based portfolio features)
- API Route Architecture (tier-based endpoint access)
- Frontend State Management (tier-based UI features)

## Change Procedure Checklist
- [ ] Update subscription database schema if needed
- [ ] Test Stripe integration and webhook processing
- [ ] Verify tier enforcement across all features
- [ ] Test billing calculation and proration logic
- [ ] Update billing dashboard UI components
- [ ] Test payment method updates and processing
- [ ] Verify usage tracking and limit enforcement
- [ ] Test upgrade/downgrade workflows
- [ ] Monitor billing analytics and reporting

## Common Change Patterns
- **New Subscription Tiers**: Adding features, changing pricing
- **Usage Limit Changes**: Adjusting feature caps, rate limits
- **Billing Workflow Updates**: Payment retry, dunning management
- **Integration Improvements**: Better Stripe synchronization

## Risk Assessment
- **Change Complexity:** HIGH - financial accuracy critical, complex integrations
- **Testing Difficulty:** HIGH - requires payment flow testing
- **Rollback Difficulty:** HARD - billing state changes affect revenue

## Owner
- **Primary:** Backend Engineering + Finance Team
- **Technical:** Senior Backend Engineer (payments specialist)
- **Business:** CFO + Head of Revenue Operations

## Financial Standards
- Payment processing accuracy 100% (no billing errors)
- Payment success rate > 98% for valid cards
- Subscription state synchronization < 1 minute lag
- Financial reporting accuracy for revenue recognition