# User Authentication & Authorization Impact Map

## Canonical Definition
Magic link-based authentication system with JWT tokens, tier-based permissions (free/pro/business/enterprise), organization management, and session handling. Supports passwordless login, email verification, and role-based access control across dashboard features.

## Business Criticality
- **Revenue Impact:** CRITICAL - security breach breaks user trust and compliance
- **User Impact:** 100% of dashboard users if auth system fails
- **Development Frequency:** 2-3 changes/month (security updates, new tiers)

## Implementation Locations

### Database Layer
- **Tables**: `users`, `sessions`, `magic_links`, `organizations` (schema.ts:80-150)
- **Auth Flow**: User creation, email verification, session management
- **Permissions**: Tier-based access levels, organization membership

### Backend API
- **Auth Routes**: `api/src/routes/auth.ts` - login, verify, logout endpoints
- **Middleware**: `api/src/middleware/auth.ts` - JWT validation, tier checking
- **Magic Links**: `api/src/services/magic-link.ts` - generation and verification
- **Email Service**: Integration with email provider for link delivery

### Frontend Auth
- **Auth Context**: `landing/lib/auth-context.tsx` - React auth state management
- **Auth Components**: Login forms, verification pages, logout handling
- **Protected Routes**: Dashboard route protection, tier-based feature gating
- **Session Management**: Token storage, refresh logic, automatic logout

### Supabase Integration
- **Auth Provider**: `landing/lib/supabase.ts` - Supabase auth configuration
- **User Management**: Supabase user records, email confirmation
- **Session Handling**: Supabase session management and token refresh

### Configuration
- **JWT Secrets**: Environment variables for token signing
- **Email Config**: SMTP settings for magic link delivery
- **Tier Definitions**: Feature access levels and usage limits

## Dependencies (concepts this relies on)
- Database Schema & Migrations (user tables)
- Environment & Configuration Management (secrets, keys)
- Email Marketing & Lifecycle (magic link delivery)

## Dependents (concepts that rely on this)
- Subscription & Billing System (user account linking)
- Alert & Notification System (user preferences)
- Portfolio Management (user data ownership)
- API Route Architecture (protected endpoints)
- Frontend State Management (user context)

## Change Procedure Checklist
- [ ] Update auth database schema if needed
- [ ] Test magic link generation and verification
- [ ] Verify JWT token validation across all routes
- [ ] Check tier-based access controls
- [ ] Test session timeout and refresh logic
- [ ] Verify frontend auth state updates
- [ ] Test logout across all devices/sessions
- [ ] Update security headers and CORS settings
- [ ] Test password-reset flow (if applicable)

## Common Change Patterns
- **New User Tiers**: Adding enterprise features, changing access levels
- **Security Updates**: JWT secret rotation, session timeout changes
- **Integration Changes**: Switching auth providers, adding SSO
- **Feature Gating**: New tier-based feature restrictions

## Risk Assessment
- **Change Complexity:** HIGH - security-critical, affects all users
- **Testing Difficulty:** HIGH - requires end-to-end auth flow testing
- **Rollback Difficulty:** HARD - session state and tokens complicate rollbacks

## Owner
- **Primary:** Full-Stack Engineering Team
- **Technical:** Senior Full-Stack Engineer (auth specialist)
- **Business:** CTO + Head of Security

## Security Considerations
- Always test auth changes in staging environment
- Monitor failed login attempts and suspicious activity
- Maintain audit logs for authentication events
- Regular security reviews of auth implementation