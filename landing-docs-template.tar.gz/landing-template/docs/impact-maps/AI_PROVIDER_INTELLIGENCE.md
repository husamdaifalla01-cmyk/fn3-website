# AI Provider Intelligence System Impact Map

## Canonical Definition
Comprehensive intelligence gathering and analysis system for AI providers (OpenAI, Anthropic, Google, etc.). Tracks pricing changes, model updates, API modifications, ToS changes, and calculates multi-dimensional risk scores. Serves as core data layer for dashboard, alerts, and portfolio analytics.

## Business Criticality
- **Revenue Impact:** HIGH - primary value proposition and differentiation
- **User Impact:** 100% of intelligence platform users
- **Development Frequency:** 5-10 changes/month (new providers, data sources, algorithms)

## Implementation Locations

### Data Models
- **Provider Data**: `landing/lib/providers-data.ts` - provider definitions, risk scores
- **Provider Metadata**: Static data for 15+ AI providers (OpenAI, Anthropic, Google, etc.)
- **Risk Calculations**: Multi-factor risk scoring (reliability, frequency, stability)

### Database Layer
- **Tables**: `providers`, `provider_changes`, `change_rollups` (schema.ts:200-350)
- **Intelligence Data**: Historical change tracking, risk score evolution
- **Analytics**: Aggregated statistics, trend analysis, comparative metrics

### Backend Services
- **Intelligence API**: `api/src/routes/intelligence.ts` - provider data endpoints
- **Risk Calculator**: `api/src/services/risk-calculator.ts` - algorithm implementation
- **Data Aggregation**: `api/src/services/analytics.ts` - rollup calculations

### Frontend Components
- **Provider Pages**: `landing/app/providers/[provider]/page.tsx` - individual provider views
- **Dashboard Feed**: `landing/components/dashboard/feed/` - provider change cards
- **Provider Cards**: Risk score displays, trend indicators, change summaries
- **Analytics Views**: Comparative analysis, industry benchmarks

### Live Data System
- **Hook**: `landing/lib/use-live-data.ts` - real-time provider data fetching
- **Provider Helpers**: `landing/lib/change-helpers.ts` - display utilities
- **Type Definitions**: TypeScript interfaces for provider data consistency

### Background Processing
- **Scrapers**: Content monitoring for provider websites
- **Change Detection**: Diff generation, confidence scoring
- **Risk Updates**: Periodic risk score recalculation
- **Data Enrichment**: External data source integration

## Dependencies (concepts this relies on)
- Change Detection & Monitoring (change data source)
- Database Schema & Migrations (provider tables)
- Background Job System (scraping, processing)
- Quality Scoring System (provider reliability metrics)

## Dependents (concepts that rely on this)
- AVRS Risk Scoring (uses provider intelligence data)
- Portfolio Management (user vendor tracking)
- Alert & Notification System (provider change alerts)
- Frontend State Management (provider data state)

## Change Procedure Checklist
- [ ] Update provider data definitions in providers-data.ts
- [ ] Modify database schema for new provider fields
- [ ] Update risk calculation algorithms if needed
- [ ] Refresh static provider metadata
- [ ] Update frontend components that display provider data
- [ ] Test all provider-specific API endpoints
- [ ] Verify dashboard feed shows updated data correctly
- [ ] Update provider comparison and analytics views
- [ ] Test alert generation for provider changes

## Common Change Patterns
- **Adding New Providers**: Expand coverage to new AI vendors
- **Risk Algorithm Updates**: Improve risk scoring accuracy
- **Data Source Changes**: New APIs, changed website structures
- **UI/UX Improvements**: Better provider data visualization

## Risk Assessment
- **Change Complexity:** MEDIUM-HIGH - affects multiple UI components
- **Testing Difficulty:** MEDIUM - requires provider data consistency testing
- **Rollback Difficulty:** MEDIUM - mostly data-driven changes

## Owner
- **Primary:** Intelligence Engineering Team
- **Technical:** Senior Frontend + Backend Engineer
- **Business:** Head of Product (intelligence features)

## Data Quality Standards
- Provider accuracy > 95% for pricing/rate limit data
- Change detection latency < 4 hours for critical updates
- Risk score consistency across all display components
- Historical data integrity for trend analysis