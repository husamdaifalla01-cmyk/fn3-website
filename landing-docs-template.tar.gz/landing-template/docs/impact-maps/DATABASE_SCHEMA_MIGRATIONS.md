# Database Schema & Migrations Impact Map

## Canonical Definition
PostgreSQL schema with 40+ interconnected tables supporting user management, AI provider intelligence, change detection, portfolio analytics, and billing. Includes complex relationships, indexing strategy, and migration management for both development and production environments.

## Business Criticality
- **Revenue Impact:** CRITICAL - data corruption breaks entire platform
- **User Impact:** 100% of users if schema changes break migrations
- **Development Frequency:** 5-8 changes/month (new features, optimizations)

## Implementation Locations

### Database Layer
- **Schema**: `api/src/db/schema.ts` (lines 1-634) - all table definitions
- **Indexes**: `api/src/db/schema.ts:580-634` - performance indexes
- **Relationships**: Foreign keys, constraints throughout schema
- **Migrations**: `api/migrations/*.sql` - version control for schema changes

### ORM Layer
- **Drizzle Config**: `api/drizzle.config.ts` - database connection config
- **Query Files**: `api/src/routes/*.ts` - complex joins and queries
- **Type Generation**: Auto-generated types from schema

### Environment Management
- **Config**: `api/src/config.ts:45-60` - database connection strings
- **Development**: Local PostgreSQL setup
- **Production**: Railway PostgreSQL or Supabase connection

### Key Tables & Relationships
- **Users/Auth**: `users`, `sessions`, `magic_links` (auth flow)
- **Providers**: `providers`, `provider_changes` (intelligence data)
- **Portfolios**: `portfolios`, `user_vendors` (user AI tracking)
- **Subscriptions**: `subscriptions`, `invoices` (billing)
- **Analytics**: `change_rollups`, `settlement_analytics` (aggregations)

## Dependencies (concepts this relies on)
- User Authentication & Authorization (user tables)
- Environment & Configuration Management (connection strings)

## Dependents (concepts that rely on this)
- ALL CONCEPTS - every feature depends on database schema
- Background Job System (data persistence)
- API Route Architecture (data queries)
- Frontend State Management (data fetching)

## Change Procedure Checklist
- [ ] Write migration script with rollback capability
- [ ] Test migration on development data copy
- [ ] Update schema.ts with new/modified tables
- [ ] Regenerate TypeScript types
- [ ] Update all affected queries and routes
- [ ] Test all dependent API endpoints
- [ ] Verify frontend components still render correctly
- [ ] Update backup/restore procedures if needed
- [ ] Plan zero-downtime deployment strategy

## Common Change Patterns
- **Adding New Tables**: New features require new data models
- **Schema Modifications**: Changing column types, adding indexes
- **Relationship Updates**: Foreign key changes, constraint modifications
- **Performance Optimizations**: Index additions, query optimizations

## Risk Assessment
- **Change Complexity:** HIGH - cascades through entire system
- **Testing Difficulty:** HIGH - requires full integration testing
- **Rollback Difficulty:** HARD - migration rollbacks are complex

## Owner
- **Primary:** Backend Engineering Team
- **Technical:** Lead Backend Engineer
- **Business:** CTO (schema changes affect platform stability)

## Migration Strategy
- Always write reversible migrations
- Test on production-sized data sets
- Plan for zero-downtime deployments
- Maintain backward compatibility during transitions