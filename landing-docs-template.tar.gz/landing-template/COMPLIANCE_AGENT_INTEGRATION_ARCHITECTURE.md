# Compliance Agent Integration Architecture

## Executive Summary

This document defines the complete integration architecture for connecting the Fortune 500-level compliance agent system to the existing repository ingestion pipeline. The compliance agents will have unrestricted access to all GitHub repositories and individual files brought through the GitHub App integration.

## Current Repository Ingestion Pipeline Analysis

### GitHub App Data Flow

```
GitHub App → Authentication → Repository Fetch → Data Transform → Database Storage
```

**Key Integration Points Identified:**

1. **Repository Storage**: `governed_repositories` table
2. **File Analysis**: `governance_data_sources_transformed` table
3. **Data Flows**: `governance_data_flows_transformed` table
4. **Business Logic**: `governance_business_entities` table
5. **File Relationships**: `governance_file_relationships` table
6. **Enhanced Metadata**: `governance_enhanced_sources` table

### Critical API Endpoints

- `/api/governance/repository/list` - Repository enumeration per user
- `/api/governance/scan` - Complete scanning pipeline
- `/api/github/repositories` - GitHub App authentication
- `/api/governance/file-content` - Individual file access

## Compliance Agent Integration Architecture

### 1. Data Access Layer

**Compliance Agent Database Adapter**
```typescript
// /lib/compliance/database-adapter.ts
export class ComplianceDataAdapter {
  // Direct table access for compliance analysis
  async getRepositoryData(repositoryId: string): Promise<RepositoryComplianceData>
  async getFileAnalysis(repositoryId: string): Promise<FileComplianceData[]>
  async getDataFlows(repositoryId: string): Promise<DataFlowComplianceData[]>
  async getBusinessEntities(repositoryId: string): Promise<BusinessEntityData[]>
  async getFileRelationships(repositoryId: string): Promise<FileRelationshipData[]>
  async getEnhancedSources(repositoryId: string): Promise<EnhancedSourceData[]>
}
```

**Repository Access Interface**
```typescript
// /lib/compliance/repository-access.ts
export interface ComplianceRepositoryAccess {
  // Unrestricted access to all user repositories
  listUserRepositories(userId: string): Promise<Repository[]>
  getRepositoryFiles(repositoryId: string): Promise<RepositoryFile[]>
  getFileContent(repositoryId: string, filePath: string): Promise<FileContent>
  getRepositoryMetadata(repositoryId: string): Promise<RepositoryMetadata>
}
```

### 2. Agent Integration Points

**Compliance Agent Base Class**
```typescript
// /lib/compliance/agents/base-agent.ts
export abstract class BaseComplianceAgent {
  protected dataAdapter: ComplianceDataAdapter
  protected repositoryAccess: ComplianceRepositoryAccess

  constructor(
    dataAdapter: ComplianceDataAdapter,
    repositoryAccess: ComplianceRepositoryAccess
  ) {
    this.dataAdapter = dataAdapter
    this.repositoryAccess = repositoryAccess
  }

  // All agents implement these core methods
  abstract analyzeRepository(repositoryId: string): Promise<ComplianceReport>
  abstract scanForViolations(repositoryId: string): Promise<ComplianceViolation[]>
  abstract generateRecommendations(repositoryId: string): Promise<ComplianceRecommendation[]>
}
```

**GDPR Agent Integration**
```typescript
// /lib/compliance/agents/gdpr-agent.ts
export class GDPRComplianceAgent extends BaseComplianceAgent {
  async analyzeRepository(repositoryId: string): Promise<GDPRComplianceReport> {
    // Access all repository data through adapters
    const repositoryData = await this.dataAdapter.getRepositoryData(repositoryId)
    const fileAnalysis = await this.dataAdapter.getFileAnalysis(repositoryId)
    const dataFlows = await this.dataAdapter.getDataFlows(repositoryId)

    // Perform GDPR-specific analysis
    const personalDataFields = this.detectPersonalDataFields(fileAnalysis)
    const dataProcessingPurposes = this.analyzeDataProcessingPurposes(dataFlows)
    const consentMechanisms = this.scanForConsentMechanisms(fileAnalysis)

    return {
      repositoryId,
      compliance: this.calculateGDPRCompliance(personalDataFields, dataProcessingPurposes, consentMechanisms),
      violations: await this.scanForViolations(repositoryId),
      recommendations: await this.generateRecommendations(repositoryId)
    }
  }
}
```

### 3. API Integration Layer

**Compliance Hub API Endpoints**
```typescript
// /app/api/compliance/analyze/route.ts
export async function POST(request: NextRequest) {
  const { repositoryId, agentType } = await request.json()

  // Initialize data adapters
  const dataAdapter = new ComplianceDataAdapter()
  const repositoryAccess = new ComplianceRepositoryAccess()

  // Select appropriate agent
  const agent = ComplianceAgentFactory.create(agentType, dataAdapter, repositoryAccess)

  // Run compliance analysis
  const report = await agent.analyzeRepository(repositoryId)

  return NextResponse.json(report)
}
```

**Repository Scan Integration**
```typescript
// /app/api/compliance/scan-repository/route.ts
export async function POST(request: NextRequest) {
  const { repositoryId } = await request.json()

  // Run all compliance agents in parallel
  const agents = [
    new GDPRComplianceAgent(dataAdapter, repositoryAccess),
    new SOXComplianceAgent(dataAdapter, repositoryAccess),
    new PCIDSSComplianceAgent(dataAdapter, repositoryAccess),
    new HIPAAComplianceAgent(dataAdapter, repositoryAccess)
  ]

  const reports = await Promise.all(
    agents.map(agent => agent.analyzeRepository(repositoryId))
  )

  return NextResponse.json({ reports })
}
```

### 4. Real-Time Integration Hooks

**Repository Scan Event Integration**
```typescript
// /app/api/governance/scan/route.ts (modified)
export async function POST(request: NextRequest) {
  // ... existing scan logic ...

  // After successful repository scan, trigger compliance analysis
  if (scanComplete) {
    // Trigger compliance agents asynchronously
    triggerComplianceAnalysis(repositoryId)
  }

  return NextResponse.json({ success: true, scanId })
}

async function triggerComplianceAnalysis(repositoryId: string) {
  // Queue compliance analysis for all agents
  await ComplianceOrchestrator.queueAnalysis(repositoryId, [
    'gdpr', 'sox', 'pci-dss', 'hipaa', 'ccpa', 'iso27001'
  ])
}
```

**GitHub Webhook Integration**
```typescript
// /app/api/github/webhooks/compliance/route.ts
export async function POST(request: NextRequest) {
  const webhook = await request.json()

  if (webhook.action === 'push' || webhook.action === 'pull_request') {
    const repositoryId = webhook.repository.id.toString()

    // Trigger incremental compliance scan
    await ComplianceOrchestrator.runIncrementalAnalysis(repositoryId)
  }

  return NextResponse.json({ received: true })
}
```

## Database Schema Extensions

### Compliance Tables

```sql
-- Compliance analysis results
CREATE TABLE compliance_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  repository_id TEXT REFERENCES governed_repositories(id),
  agent_type TEXT NOT NULL, -- 'gdpr', 'sox', 'pci-dss', etc.
  compliance_score DECIMAL(3,2), -- 0.00 to 1.00
  risk_level TEXT CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
  report_data JSONB NOT NULL,
  violations JSONB DEFAULT '[]'::jsonb,
  recommendations JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Compliance violations tracking
CREATE TABLE compliance_violations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  repository_id TEXT REFERENCES governed_repositories(id),
  agent_type TEXT NOT NULL,
  violation_type TEXT NOT NULL,
  severity TEXT CHECK (severity IN ('info', 'warning', 'error', 'critical')),
  file_path TEXT,
  line_number INTEGER,
  description TEXT NOT NULL,
  remediation TEXT,
  status TEXT DEFAULT 'open' CHECK (status IN ('open', 'resolved', 'false_positive')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  resolved_at TIMESTAMPTZ
);

-- Compliance recommendations
CREATE TABLE compliance_recommendations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  repository_id TEXT REFERENCES governed_repositories(id),
  agent_type TEXT NOT NULL,
  category TEXT NOT NULL,
  priority TEXT CHECK (priority IN ('low', 'medium', 'high', 'critical')),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  implementation_guide TEXT,
  estimated_effort TEXT,
  business_impact TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'dismissed')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### Existing Table Extensions

```sql
-- Add compliance metadata to existing tables
ALTER TABLE governed_repositories
ADD COLUMN compliance_score DECIMAL(3,2),
ADD COLUMN last_compliance_scan TIMESTAMPTZ,
ADD COLUMN compliance_status TEXT DEFAULT 'pending';

ALTER TABLE governance_data_sources_transformed
ADD COLUMN privacy_classification TEXT,
ADD COLUMN data_sensitivity_level TEXT,
ADD COLUMN compliance_flags JSONB DEFAULT '{}'::jsonb;

ALTER TABLE governance_data_flows_transformed
ADD COLUMN gdpr_lawful_basis TEXT,
ADD COLUMN data_retention_period TEXT,
ADD COLUMN cross_border_transfer BOOLEAN DEFAULT FALSE,
ADD COLUMN encryption_status TEXT;
```

## Integration Implementation Plan

### Phase 1: Core Adapter Layer (Week 1)

1. **Create ComplianceDataAdapter** - Direct database access
2. **Create ComplianceRepositoryAccess** - Repository file access
3. **Create BaseComplianceAgent** - Agent foundation
4. **Extend existing API routes** - Add compliance hooks

### Phase 2: Agent Integration (Week 2)

1. **Implement GDPR Agent** - Full GDPR compliance analysis
2. **Implement SOX Agent** - Financial compliance
3. **Create ComplianceOrchestrator** - Multi-agent coordination
4. **Build API endpoints** - `/api/compliance/*` routes

### Phase 3: Real-Time Integration (Week 3)

1. **GitHub webhook integration** - Real-time compliance monitoring
2. **Scan pipeline integration** - Auto-trigger compliance analysis
3. **Dashboard integration** - Compliance results in UI
4. **Notification system** - Alert on compliance violations

### Phase 4: Advanced Features (Week 4)

1. **Incremental analysis** - Delta compliance scanning
2. **Custom compliance policies** - User-defined rules
3. **Compliance reporting** - Automated report generation
4. **Audit trails** - Complete compliance history

## Data Flow Architecture

```
GitHub App Integration
         ↓
Repository Ingestion Pipeline
         ↓
Database Storage (governed_repositories, governance_*)
         ↓
Compliance Data Adapter
         ↓
Compliance Agents (GDPR, SOX, PCI-DSS, HIPAA)
         ↓
Compliance Reports & Violations
         ↓
Compliance Hub UI
```

## Security Considerations

1. **Data Access Control**: Compliance agents inherit user permissions
2. **Audit Logging**: All compliance analysis actions logged
3. **Encryption**: Sensitive compliance data encrypted at rest
4. **Rate Limiting**: Compliance API endpoints rate limited
5. **Access Tokens**: GitHub App tokens secured and rotated

## Performance Optimization

1. **Parallel Analysis**: Multiple agents run simultaneously
2. **Incremental Scanning**: Only analyze changed files
3. **Caching Layer**: Cache compliance results for 24 hours
4. **Background Processing**: Long-running analysis in queue
5. **Database Indexing**: Optimize queries on repository_id

## Monitoring & Observability

1. **Compliance Metrics**: Track analysis success rates
2. **Performance Monitoring**: Agent execution times
3. **Error Tracking**: Compliance analysis failures
4. **Business Metrics**: Compliance scores over time
5. **Alert System**: Critical compliance violations

This architecture provides complete integration between the compliance agent system and the existing repository ingestion pipeline, ensuring Fortune 500-level compliance analysis with unrestricted access to all GitHub repository data.