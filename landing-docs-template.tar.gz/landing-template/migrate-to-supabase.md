# Migrate to Supabase - Step by Step Guide

## 1. Get Your Supabase Credentials

Go to your Supabase dashboard at https://rljuvftaaxhvdmlkijxo.supabase.co

### Settings → API:
- **Project URL**: `https://rljuvftaaxhvdmlkijxo.supabase.co` ✅ (already configured)
- **Anon/Public Key**: Copy this and add to `.env.local`

### Settings → Database:
- **Connection String**: Copy the connection pooling string for migrations

## 2. Update Environment Variables

### Local Development (`/Users/husamahmed/x402/landing/.env.local`):
```
NEXT_PUBLIC_SUPABASE_URL=https://rljuvftaaxhvdmlkijxo.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_actual_anon_key_from_dashboard
```

### Vercel Production:
```bash
vercel env add NEXT_PUBLIC_SUPABASE_URL production --value "https://rljuvftaaxhvdmlkijxo.supabase.co" --yes
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY production --value "your_actual_anon_key" --yes
```

## 3. Apply Database Schema to Supabase

You have two options:

### Option A: Use Supabase Dashboard (Recommended)
1. Go to SQL Editor in your Supabase dashboard
2. Copy the contents of `/Users/husamahmed/x402/supabase/migrations/0000_odd_roxanne_simpson.sql`
3. Paste and run the SQL

### Option B: Use Supabase CLI
```bash
# From the /Users/husamahmed/x402 directory
supabase db push --db-url "your_connection_string_from_supabase_dashboard"
```

## 4. Enable Authentication in Supabase

In your Supabase dashboard:
1. Go to **Authentication → Settings**
2. Enable **Email** provider
3. Configure **Site URL**: `https://your-vercel-domain.vercel.app`
4. Add **Redirect URLs**:
   - `https://your-vercel-domain.vercel.app/dashboard`
   - `http://localhost:3000/dashboard` (for local dev)

## 5. Test Authentication

1. Build and run locally: `npm run dev`
2. Go to `/login` - should show Supabase setup instructions if env vars missing
3. Add your anon key to `.env.local`
4. Restart dev server
5. Try signing up with a test email

## 6. Deploy to Production

```bash
npm run build
vercel --prod
```

The authentication should now work in production!

## 7. Data Migration (Optional)

If you have existing users in your local PostgreSQL:

1. Export users:
```sql
SELECT id, email, password_hash, tier, is_verified, created_at, last_login_at
FROM verdict_users;
```

2. Import to Supabase using the SQL editor or pg_dump/pg_restore

## Next Steps

Once auth is working:
- Update any API calls that were using your Express backend to use Supabase
- Remove the custom auth backend dependencies
- Test all auth flows (signup, login, logout, protected routes)