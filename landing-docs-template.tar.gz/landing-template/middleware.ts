import { createServerClient } from '@supabase/ssr';
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export async function middleware(req: NextRequest) {
  let supabaseResponse = NextResponse.next({
    request: req,
  });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return req.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value, options }) => {
            req.cookies.set(name, value);
            supabaseResponse = NextResponse.next({
              request: req,
            });
            supabaseResponse.cookies.set(name, value, options);
          });
        },
      }
    }
  );

  // Refresh session if expired - this is important for SSR
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Paths that require authentication
  const protectedPaths = [
    '/dashboard',
    '/api/github/app/install/state',
    '/api/github/app/installations',
    '/api/governance',
  ];

  const path = req.nextUrl.pathname;
  const isProtectedPath = protectedPaths.some(p => path.startsWith(p));

  // Allow webhook and auth callback endpoints without authentication
  if (path.startsWith('/api/github/app/webhook') ||
      path.startsWith('/api/github/auth/callback') ||
      path.startsWith('/auth/callback') ||
      path.startsWith('/auth/hash-callback')) {
    return supabaseResponse;
  }

  // Require authentication for protected paths
  // PRODUCTION SECURITY: Authentication is REQUIRED for protected routes
  if (isProtectedPath && !user) {
    const redirectUrl = req.nextUrl.clone();
    redirectUrl.pathname = '/login';
    redirectUrl.searchParams.set('redirect', req.nextUrl.pathname);
    return NextResponse.redirect(redirectUrl);
  }

  return supabaseResponse;
}

// Configure which routes should be processed by the middleware
export const config = {
  matcher: [
    '/dashboard/:path*',
    '/api/github/app/install/state',
    '/api/github/app/installations',
    '/api/governance/:path*',
    '/auth/:path*',
  ]
};