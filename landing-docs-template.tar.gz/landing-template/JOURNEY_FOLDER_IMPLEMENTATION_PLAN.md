# Deep Implementation Plan: Journey-Based File Organization System

## Current State Analysis

### What's Already Built ✅
1. **GitHub App Integration**: Live repository data flowing through `/api/github/repositories`
2. **Data Sources API**: `/api/governance/data-sources-transformed` with live business intelligence
3. **Repository Selection**: Dropdown populated with live GitHub repos using `github-{id}` format
4. **Database Schema**:
   - `governance_data_sources_transformed` table with repository_id, entity_name, entity_category
   - `governed_repositories` table with GitHub integration fields
   - Live data for UserService, PaymentProcessor, ReportingService entities

### What Needs to be Built 🚧

---

## PHASE 1: Database Schema Extensions

### Task 1.1: Create Journey Management Tables
```sql
-- Journey definitions table
CREATE TABLE governance_user_journeys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  repository_id TEXT NOT NULL, -- Format: github-{id}
  journey_name TEXT NOT NULL,
  journey_description TEXT,
  journey_type TEXT NOT NULL, -- 'user_registration', 'payment_processing', 'data_export', etc.
  auto_discovery_enabled BOOLEAN DEFAULT true,
  compliance_frameworks TEXT[], -- ['GDPR', 'CCPA', 'PCI-DSS']
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(repository_id, journey_name)
);

-- Journey file associations table
CREATE TABLE governance_journey_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  journey_id UUID NOT NULL REFERENCES governance_user_journeys(id) ON DELETE CASCADE,
  file_path TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_type TEXT NOT NULL, -- 'auto_discovered', 'manually_added'
  discovery_confidence FLOAT DEFAULT 0.0, -- 0.0 to 1.0 for auto-discovered files
  discovery_reasoning JSONB, -- AI reasoning for why file belongs to journey
  compliance_status TEXT DEFAULT 'pending', -- 'pending', 'compliant', 'non_compliant', 'review_required'
  compliance_findings JSONB, -- Detailed compliance analysis results
  added_by_user_id UUID,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(journey_id, file_path)
);

-- Journey compliance analysis table
CREATE TABLE governance_journey_compliance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  journey_id UUID NOT NULL REFERENCES governance_user_journeys(id) ON DELETE CASCADE,
  compliance_framework TEXT NOT NULL, -- 'GDPR', 'CCPA', etc.
  compliance_score FLOAT NOT NULL, -- 0.0 to 1.0
  compliance_status TEXT NOT NULL, -- 'compliant', 'non_compliant', 'partial_compliant'
  violations JSONB, -- Array of violation objects
  recommendations JSONB, -- Array of recommendation objects
  last_analyzed_at TIMESTAMP DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(journey_id, compliance_framework)
);
```

### Task 1.2: Add Indexes for Performance
```sql
CREATE INDEX idx_journey_files_journey_id ON governance_journey_files(journey_id);
CREATE INDEX idx_journey_files_file_type ON governance_journey_files(file_type);
CREATE INDEX idx_journey_compliance_journey_id ON governance_journey_compliance(journey_id);
CREATE INDEX idx_user_journeys_repository_id ON governance_user_journeys(repository_id);
```

---

## PHASE 2: Backend API Development

### Task 2.1: Journey Management API
**File**: `/api/governance/journeys/route.ts`
```typescript
// GET /api/governance/journeys?repositoryId=github-123
// Returns all journeys for a repository
export async function GET(request: NextRequest) {
  // 1. Extract repositoryId from query params
  // 2. Authenticate user session
  // 3. Query governance_user_journeys table
  // 4. Include file count and compliance status for each journey
  // 5. Return journey list with metadata
}

// POST /api/governance/journeys
// Creates a new journey
export async function POST(request: NextRequest) {
  // 1. Validate journey data (name, description, type, frameworks)
  // 2. Create journey in database
  // 3. Trigger auto-discovery if enabled
  // 4. Return created journey with initial file scan results
}
```

### Task 2.2: File Discovery API
**File**: `/api/governance/journeys/[journeyId]/discover/route.ts`
```typescript
// POST /api/governance/journeys/{journeyId}/discover
// Triggers AI-powered file discovery for a journey
export async function POST(request: NextRequest) {
  // 1. Get journey details and repository info
  // 2. Fetch repository file tree from GitHub API
  // 3. Use AI/ML to classify files by journey relevance
  // 4. Score each file (confidence 0.0-1.0)
  // 5. Insert auto-discovered files into governance_journey_files
  // 6. Return discovery results with confidence scores
}
```

### Task 2.3: Journey Files Management API
**File**: `/api/governance/journeys/[journeyId]/files/route.ts`
```typescript
// GET /api/governance/journeys/{journeyId}/files
// Returns all files for a journey (auto + manual)
export async function GET(request: NextRequest) {
  // 1. Query governance_journey_files for journey
  // 2. Fetch file content summaries from GitHub API
  // 3. Include compliance status for each file
  // 4. Return organized file list with metadata
}

// POST /api/governance/journeys/{journeyId}/files
// Manually adds files to a journey
export async function POST(request: NextRequest) {
  // 1. Validate file paths exist in repository
  // 2. Check for duplicates
  // 3. Insert as 'manually_added' type
  // 4. Trigger compliance analysis for new files
  // 5. Return updated file list
}

// DELETE /api/governance/journeys/{journeyId}/files/{fileId}
// Removes a file from a journey
export async function DELETE(request: NextRequest) {
  // 1. Verify file belongs to journey
  // 2. Delete from governance_journey_files
  // 3. Update journey compliance scores
  // 4. Return success confirmation
}
```

### Task 2.4: Compliance Analysis API
**File**: `/api/governance/journeys/[journeyId]/compliance/route.ts`
```typescript
// GET /api/governance/journeys/{journeyId}/compliance
// Returns compliance analysis for journey
export async function GET(request: NextRequest) {
  // 1. Query governance_journey_compliance table
  // 2. Aggregate file-level compliance findings
  // 3. Calculate overall journey compliance score
  // 4. Return detailed compliance report
}

// POST /api/governance/journeys/{journeyId}/compliance/analyze
// Triggers compliance analysis for all journey files
export async function POST(request: NextRequest) {
  // 1. Get all files in journey
  // 2. Fetch file contents from GitHub API
  // 3. Run compliance analysis against selected frameworks
  // 4. Store results in governance_journey_compliance
  // 5. Return analysis results
}
```

---

## PHASE 3: AI-Powered File Discovery Engine

### Task 3.1: Journey Classification Service
**File**: `/lib/services/journey-classifier.ts`
```typescript
class JourneyClassifier {
  // Analyzes repository files and classifies them by journey type
  async classifyFilesByJourney(
    repositoryId: string,
    files: GitHubFile[],
    journeyType: string
  ): Promise<ClassifiedFile[]> {
    // 1. Define journey patterns (regex, keywords, file paths)
    // 2. Use ML/AI to score file relevance to journey
    // 3. Consider file imports/dependencies for context
    // 4. Return scored file list with reasoning
  }

  // Journey type definitions with file patterns
  private readonly journeyPatterns = {
    user_registration: {
      keywords: ['signup', 'register', 'auth', 'user', 'account'],
      paths: ['/auth/', '/signup/', '/user/', '/registration/'],
      fileTypes: ['.tsx', '.ts', '.js', '.vue', '.py'],
      excludes: ['/test/', '/spec/', '/mock/']
    },
    payment_processing: {
      keywords: ['payment', 'billing', 'stripe', 'checkout', 'price'],
      paths: ['/payment/', '/billing/', '/checkout/', '/pricing/'],
      fileTypes: ['.tsx', '.ts', '.js', '.py', '.php'],
      excludes: ['/test/', '/spec/', '/mock/']
    },
    data_export: {
      keywords: ['export', 'download', 'csv', 'pdf', 'report'],
      paths: ['/export/', '/download/', '/reports/'],
      fileTypes: ['.tsx', '.ts', '.js', '.py'],
      excludes: ['/test/', '/spec/', '/mock/']
    }
  };
}
```

### Task 3.2: File Content Analyzer
**File**: `/lib/services/file-analyzer.ts`
```typescript
class FileAnalyzer {
  // Analyzes individual file content for journey relevance
  async analyzeFileContent(
    filePath: string,
    content: string,
    journeyType: string
  ): Promise<AnalysisResult> {
    // 1. Parse file content (AST for code files)
    // 2. Extract function names, imports, exports
    // 3. Analyze data flow and business logic
    // 4. Score relevance to journey with reasoning
    // 5. Return detailed analysis with confidence score
  }

  // Extract business context from code
  private extractBusinessContext(content: string): BusinessContext {
    // 1. Identify data handling patterns
    // 2. Find API endpoints and their purposes
    // 3. Detect user interaction points
    // 4. Map data transformations
  }
}
```

---

## PHASE 4: Frontend Journey Management UI

### Task 4.1: Journey Overview Component
**File**: `/components/governance/journey-overview.tsx`
```tsx
interface JourneyOverviewProps {
  repositoryId: string;
}

export function JourneyOverview({ repositoryId }: JourneyOverviewProps) {
  // 1. Fetch journeys for repository
  // 2. Display journey cards with file counts and compliance status
  // 3. Provide "Create New Journey" button
  // 4. Show journey analytics (total files, compliance scores)

  return (
    <div className="journey-overview">
      <div className="journey-header">
        <h2>User Journeys</h2>
        <Button onClick={() => setShowCreateModal(true)}>
          <Plus className="h-4 w-4" />
          Create Journey
        </Button>
      </div>

      <div className="journey-grid">
        {journeys.map(journey => (
          <JourneyCard
            key={journey.id}
            journey={journey}
            onClick={() => setSelectedJourney(journey)}
          />
        ))}
      </div>
    </div>
  );
}
```

### Task 4.2: Journey Folder Component
**File**: `/components/governance/journey-folder.tsx`
```tsx
interface JourneyFolderProps {
  journey: UserJourney;
  repositoryId: string;
}

export function JourneyFolder({ journey, repositoryId }: JourneyFolderProps) {
  // 1. Display journey as expandable folder
  // 2. Show auto-discovered files with confidence badges
  // 3. Show manually added files with different styling
  // 4. Provide file addition interface
  // 5. Show compliance status for each file

  return (
    <div className="journey-folder">
      <div className="folder-header" onClick={() => setExpanded(!expanded)}>
        <FolderOpen className="h-5 w-5" />
        <span className="folder-name">{journey.journey_name}</span>
        <Badge variant="secondary">{files.length} files</Badge>
        <ComplianceStatusBadge status={journey.compliance_status} />
      </div>

      {expanded && (
        <div className="folder-content">
          <div className="auto-discovered-section">
            <h4>🔍 Auto-discovered Files</h4>
            {autoFiles.map(file => (
              <FileItem
                key={file.id}
                file={file}
                showConfidence={true}
                onRemove={() => removeFile(file.id)}
              />
            ))}
          </div>

          <div className="manual-files-section">
            <h4>➕ Manually Added Files</h4>
            {manualFiles.map(file => (
              <FileItem
                key={file.id}
                file={file}
                showConfidence={false}
                onRemove={() => removeFile(file.id)}
              />
            ))}

            <FileAddDropzone
              onFilesAdded={(files) => addFilesToJourney(journey.id, files)}
            />
          </div>
        </div>
      )}
    </div>
  );
}
```

### Task 4.3: File Addition Interface
**File**: `/components/governance/file-add-dropzone.tsx`
```tsx
interface FileAddDropzoneProps {
  repositoryId: string;
  journeyId: string;
  onFilesAdded: (files: string[]) => void;
}

export function FileAddDropzone({ repositoryId, journeyId, onFilesAdded }: FileAddDropzoneProps) {
  // 1. Show repository file browser
  // 2. Allow drag-and-drop file selection
  // 3. Support multi-file selection
  // 4. Validate files exist in repository
  // 5. Show preview of files to be added

  return (
    <div className="file-add-interface">
      <div className="dropzone" onDrop={handleFileDrop}>
        <FileText className="h-8 w-8 text-gray-400" />
        <p>Drag files here or browse repository</p>
        <Button variant="outline" onClick={() => setShowBrowser(true)}>
          Browse Files
        </Button>
      </div>

      {showBrowser && (
        <RepositoryFileBrowser
          repositoryId={repositoryId}
          onFilesSelected={handleFilesSelected}
          excludeExisting={true}
        />
      )}
    </div>
  );
}
```

### Task 4.4: Compliance Analysis Dashboard
**File**: `/components/governance/journey-compliance-dashboard.tsx`
```tsx
interface ComplianceDashboardProps {
  journey: UserJourney;
}

export function JourneyComplianceDashboard({ journey }: ComplianceDashboardProps) {
  // 1. Show compliance scores for each framework
  // 2. Display violations and recommendations
  // 3. Provide file-level compliance details
  // 4. Allow framework selection/configuration
  // 5. Show compliance trends over time

  return (
    <div className="compliance-dashboard">
      <div className="compliance-overview">
        {journey.compliance_frameworks.map(framework => (
          <ComplianceCard
            key={framework}
            framework={framework}
            score={getComplianceScore(framework)}
            status={getComplianceStatus(framework)}
          />
        ))}
      </div>

      <div className="compliance-details">
        <Tabs>
          <TabsList>
            <TabsTrigger value="violations">Violations</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            <TabsTrigger value="file-details">File Details</TabsTrigger>
          </TabsList>

          <TabsContent value="violations">
            <ViolationsList violations={violations} />
          </TabsContent>

          <TabsContent value="recommendations">
            <RecommendationsList recommendations={recommendations} />
          </TabsContent>

          <TabsContent value="file-details">
            <FileComplianceGrid files={journeyFiles} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
```

---

## PHASE 5: Integration with Existing Data Mapping Page

### Task 5.1: Add Journey Tab to Data Mapping
**File**: `/app/(dashboard)/dashboard/governance/data-mapping/page.tsx`
```tsx
// Add new tab to existing tabs
<Tabs value={activeTab} onValueChange={setActiveTab}>
  <TabsList>
    <TabsTrigger value="data-sources">Data Sources</TabsTrigger>
    <TabsTrigger value="data-flows">Data Flows</TabsTrigger>
    <TabsTrigger value="architecture">Architecture</TabsTrigger>
    <TabsTrigger value="journeys">User Journeys</TabsTrigger> {/* NEW */}
  </TabsList>

  {/* Existing tabs... */}

  <TabsContent value="journeys">
    <JourneyManagementTab
      repositoryId={selectedRepositoryId}
      dataSources={dataSources}
    />
  </TabsContent>
</Tabs>
```

### Task 5.2: Journey Management Tab Component
**File**: `/components/governance/journey-management-tab.tsx`
```tsx
interface JourneyManagementTabProps {
  repositoryId: string;
  dataSources: DataSource[];
}

export function JourneyManagementTab({ repositoryId, dataSources }: JourneyManagementTabProps) {
  // 1. Load journeys for selected repository
  // 2. Display journey folders with file organization
  // 3. Show compliance status across all journeys
  // 4. Provide journey creation and management tools
  // 5. Integrate with existing data sources for context

  return (
    <div className="journey-management">
      <div className="journey-controls">
        <div className="flex justify-between items-center">
          <h3>User Journey Analysis</h3>
          <div className="flex gap-2">
            <Button onClick={() => triggerAutoDiscovery()}>
              <Zap className="h-4 w-4" />
              Auto-Discover Files
            </Button>
            <Button onClick={() => setShowCreateModal(true)}>
              <Plus className="h-4 w-4" />
              New Journey
            </Button>
          </div>
        </div>
      </div>

      <div className="journey-content">
        <div className="journey-sidebar">
          <JourneyOverview repositoryId={repositoryId} />
        </div>

        <div className="journey-details">
          {selectedJourney ? (
            <>
              <JourneyFolder
                journey={selectedJourney}
                repositoryId={repositoryId}
              />
              <JourneyComplianceDashboard
                journey={selectedJourney}
              />
            </>
          ) : (
            <EmptyJourneyState
              onCreateJourney={() => setShowCreateModal(true)}
            />
          )}
        </div>
      </div>
    </div>
  );
}
```

---

## PHASE 6: Live Data Integration Points

### Task 6.1: Connect All Components to Live GitHub Data
1. **Repository Selection**: Already working ✅
2. **File Browser**: Use GitHub API to fetch real repository file tree
3. **File Content**: Fetch actual file contents from GitHub API for analysis
4. **Auto-Discovery**: Scan real repository structure and file contents
5. **Compliance Analysis**: Analyze actual code for compliance issues

### Task 6.2: Real-time Updates
1. **WebSocket Connection**: For real-time compliance status updates
2. **GitHub Webhooks**: Trigger re-analysis when repository changes
3. **Background Jobs**: Queue compliance analysis for large repositories
4. **Cache Management**: Invalidate caches when repository data changes

---

## PHASE 7: Testing and Validation

### Task 7.1: Component Testing
- Test journey creation and file discovery
- Verify compliance analysis accuracy
- Test file addition/removal workflows
- Validate GitHub API integration

### Task 7.2: End-to-End Testing
- Complete user journey from repository selection to compliance analysis
- Test with multiple repository types and sizes
- Verify data consistency across all components

---

## Implementation Order Priority:
1. **Phase 1**: Database schema (foundation)
2. **Phase 2**: Core APIs (backend functionality)
3. **Phase 3**: AI discovery engine (smart features)
4. **Phase 4**: UI components (user interface)
5. **Phase 5**: Integration (connect to existing)
6. **Phase 6**: Live data (real-time features)
7. **Phase 7**: Testing (quality assurance)

Each phase should be completed and tested before moving to the next phase. The system should remain functional throughout the implementation process.

---

## Key Requirements Summary:
- Each journey acts as a "folder" containing relevant files
- Auto-discovery of files using AI/ML classification
- Manual file addition capability for users
- Compliance analysis per journey against selected frameworks
- All UI components must use live GitHub repository data
- Integration with existing data mapping page as new tab
- Real-time updates when repository changes