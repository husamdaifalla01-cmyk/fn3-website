# Governance API Mapping

## API Endpoints and Usage

### 🗂️ Repository Management

#### `/api/governance/repository/list` - GET
**Purpose**: Get list of all repositories for user
**Used in**:
- `app/(dashboard)/dashboard/governance/data-mapping/page.tsx:355` - Load available repositories for dropdown
- `lib/repository-context.tsx:45` - Repository context provider
- `components/governance/github-repository-manager.tsx` (implied)

#### `/api/governance/repository/add` - POST
**Purpose**: Add new repository to governance system
**Used in**:
- `components/governance/enhanced-repository-addition-center.tsx:89` - Add repository flow

#### `/api/governance/repository/save` - POST
**Purpose**: Save repository configuration
**Used in**:
- `components/governance/github-repository-manager.tsx:142` - Save repository after GitHub OAuth

#### `/api/governance/repository/simple-add` - POST
**Purpose**: Simple repository addition without complex flows
**Used in**: Not actively used in frontend

#### `/api/governance/repositories` - GET/POST
**Purpose**: Repository analysis and management
**Used in**:
- `components/governance/github-app-integration.tsx:87` - Repository analysis
- `components/governance/github-integration.tsx:45` - Repository scanning

### 📊 Data Sources

#### `/api/governance/data-sources` - GET
**Purpose**: Get data sources for a repository (real-time GitHub scanning)
**Used in**:
- `app/(dashboard)/dashboard/governance/data-mapping/page.tsx:390` - Main data sources loading
- `components/governance/enhanced-data-sources-tab.tsx:243` - Data sources fetching

#### `/api/governance/data-sources-transformed` - GET
**Purpose**: Get transformed/processed data sources
**Used in**:
- `components/governance/enhanced-data-sources-tab.tsx` (was trying to use this)

### 🔄 Data Flows

#### `/api/governance/data-flows-transformed` - GET
**Purpose**: Get transformed data flows
**Used in**:
- `components/governance/enhanced-data-flows-tab.tsx:58` - Data flows visualization

### 🏗️ Architecture

#### `/api/governance/architecture-transformed` - GET
**Purpose**: Get transformed architecture data
**Used in**:
- `components/governance/enhanced-architecture-tab.tsx:58` - Architecture visualization

### 📄 File Content

#### `/api/governance/file-content` - GET
**Purpose**: Get file content from GitHub repositories
**Used in**:
- `components/governance/file-content-modal.tsx:71` - File content modal
- `components/governance/enhanced-data-sources-tab.tsx:518` - File viewing

### 🔍 Scanning & Analysis

#### `/api/governance/scan` - GET/POST
**Purpose**: Start repository scans and get scan results
**Used in**:
- `components/governance/enhanced-data-sources-tab.tsx:889` - Start repository scan button

#### `/api/governance/scan-status/[scanId]` - GET
**Purpose**: Get scan status by scan ID
**Used in**:
- `components/governance/scan-progress-monitor.tsx:31` - Monitor scan progress

### 📋 Repository Data

#### `/api/governance/repository/[id]/distributed-data` - GET
**Purpose**: Get distributed/processed data for repository
**Used in**:
- `app/(dashboard)/dashboard/governance/data-mapping/page.tsx:25` - Repository analysis
- `app/(dashboard)/dashboard/governance/documentation/page.tsx:54` - Documentation data
- `app/(dashboard)/dashboard/governance/compliance/page.tsx:54` - Compliance data
- `components/governance/editable-architecture-canvas.tsx:131` - Architecture canvas

#### `/api/governance/repository/[id]/extract-flows` - POST
**Purpose**: Extract data flows from repository files
**Used in**:
- `app/(dashboard)/dashboard/governance/data-mapping/page.tsx:555` - File extraction

#### `/api/governance/repository/[id]/scan-files` - GET
**Purpose**: Scan files in repository
**Used in**:
- `components/governance/database-file-picker.tsx:47` - File picker

### 🔄 Transformations

#### `/api/governance/transformations/data-sources` - POST
**Purpose**: Transform raw data to data sources format
**Used in**:
- `app/api/governance/enhanced-ingestion/route.ts:89` - Enhanced ingestion pipeline

#### `/api/governance/transformations/data-flows` - POST
**Purpose**: Transform raw data to data flows format
**Used in**:
- `app/api/governance/enhanced-ingestion/route.ts:99` - Enhanced ingestion pipeline

#### `/api/governance/transformations/architecture` - POST
**Purpose**: Transform raw data to architecture format
**Used in**:
- `app/api/governance/enhanced-ingestion/route.ts:109` - Enhanced ingestion pipeline

### 🚀 Enhanced Ingestion

#### `/api/governance/enhanced-ingestion` - POST
**Purpose**: Main ingestion pipeline for repositories
**Used in**:
- `app/api/governance/repository/add/route.ts:89` - Repository addition
- `app/api/governance/repository/save/route.ts:84` - Repository saving
- `app/api/github/trigger-scan/route.ts:89` - GitHub triggered scans
- `components/governance/enhanced-repository-addition-center.tsx:127` - Enhanced ingestion

### 📋 Data Mapping

#### `/api/governance/data-mapping` - GET
**Purpose**: Get data mapping visualization data
**Used in**: Referenced but no active usage found

### 🔄 General Transformation

#### `/api/governance/transformation` - GET/POST
**Purpose**: General data transformation endpoint
**Used in**:
- `app/api/governance/enhanced-ingestion/route.ts:149` - Transformation processing

### 💾 Cache Management

#### `/api/governance/cache` - GET/DELETE/POST
**Purpose**: Cache management for governance data
**Used in**: Internal cache management, no direct frontend usage

### 📋 Policies

#### `/api/governance/policies` - GET/POST
**Purpose**: Governance policies management
**Used in**: Not actively used in current frontend

### 📂 Upload

#### `/api/governance/upload` - POST
**Purpose**: File upload for governance analysis
**Used in**: Not actively used in current frontend

### 🔄 Repository Sync

#### `/api/governance/sync-repositories` - POST
**Purpose**: Sync repositories with external sources
**Used in**: Background sync operations

### 📋 Repository Ingestion Analysis

#### `/api/governance/repository-ingestion` - GET/POST
**Purpose**: Repository ingestion analysis and planning
**Used in**: Not actively used in current frontend

---

## Usage Patterns

### 🔄 Data Flow in Data Mapping Page
1. `repository/list` → Load available repositories
2. `data-sources?repositoryId=X` → Load data sources for selected repo
3. `file-content?path=X&repository_id=Y` → View file content
4. `scan` → Start repository scan if no data

### 🔍 Scan Workflow
1. `scan` POST → Start scan
2. `scan-status/[id]` → Monitor progress
3. `repository/[id]/distributed-data` → Get results

### 🏗️ Enhanced Ingestion Pipeline
1. `repository/add` → Add repository
2. `enhanced-ingestion` → Process repository
3. `transformations/*` → Transform data
4. `transformation` → Final processing

### 📊 Visualization Tabs
- **Data Sources**: `data-sources` + `data-sources-transformed`
- **Data Flows**: `data-flows-transformed`
- **Architecture**: `architecture-transformed`

---

## Database Tables Used
- `governance_repositories` - Repository metadata
- `governance_scans` - Scan records and results
- `governance_data_sources` - Raw data sources
- `governance_data_sources_transformed` - Processed data sources
- `governance_data_flows_transformed` - Processed data flows
- `governance_architecture_transformed` - Processed architecture

---

## Key Issues Found
1. **`data-sources-transformed`** - Referenced but data not stored there
2. **Real-time vs Stored** - Mix of real-time GitHub API and stored data
3. **Scan Integration** - Scans store data but not connected to main data sources display
4. **Unused Endpoints** - Several endpoints defined but not used in frontend